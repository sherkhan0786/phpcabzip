
            <ul class="nav flex-column pb-5 sbar">
                <li class="nav-item sbaritem">
                    <a class="nav-link active linkItem" aria-current="page" href="#">HOME</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#">UPDATE PROFILE</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#">UPDATE NEWS</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#" tabindex="-1">UPDATE NOTICE</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#" tabindex="-1">CILENT LIST</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#" tabindex="-1">ADD</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#" tabindex="-1">UPDATE REPORT</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#" tabindex="-1">CAREER REQUEST</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#" tabindex="-1">UPLOAD EXCEL</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#" tabindex="-1">ANALYSYS REPORT</a>
                </li>
                <li class="nav-item sbaritem">
                    <a class="nav-link linkItem" href="#" tabindex="-1">CED CAB</a>
                </li>
            </ul>
          