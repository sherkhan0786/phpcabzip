
<footer>
    <div class="container mt-5 py-4 text-center">
        <div class="row">
            <div class="col-md-4">
                <!-- <p> -->
                <i class="fa fa-twitter-square" aria-hidden="true"></i>
                <i class="fa fa-facebook-square" aria-hidden="true"></i>
                <i class="fa fa-facebook-square" aria-hidden="true"></i>
                <!-- </p> -->
            </div>
            <div class="col-md-4">
                <!-- <p> -->
                    CopyRight @ 2016-2021
                <!-- </p> -->
            </div>
            <div class="col-md-4">
                <!-- <p> -->
                    <a href="">ABOUTUS</a>
                    <a href="">CONTACTUS</a>
                    <a href="">DISCLAIMER</a>
                <!-- </p> -->
            </div>
        </div>
    </div>
</footer>